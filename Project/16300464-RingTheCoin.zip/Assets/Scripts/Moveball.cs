using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Moveball : MonoBehaviour
{
    Rigidbody rb;
    public int BallSpeed;
    public int JumpSpeed = 0;
    private bool istouching = true;
    private int count;
    public Text cointext;
    public AudioClip audio;
    public AudioSource audiosource;
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        count = 0;
        cointext.text = "SCORE: "+ count;
    }

    // Update is called once per frame
    void Update()
    {
        float hmove = Input.GetAxis("Horizontal");
        float vmove = Input.GetAxis("Vertical");
        Vector3 ballmove = new Vector3( hmove,0.0f ,vmove );
        rb.AddForce(ballmove * BallSpeed);
        if((Input.GetKey(KeyCode.Space)) && istouching==true )
        {
            Vector3 jump = new Vector3(0.0f, 6.0f, 0.0f);
            rb.AddForce(jump*JumpSpeed);
        }
        istouching = false;
    }
    private void OnCollisionStay()
    {
        istouching = true;
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("CoinTag"))
        {
            other.gameObject.SetActive(false);
            count = count + 1;
            cointext.text = "SCORE: " + count;
            audiosource.PlayOneShot(audio);
            if(count==11)
            {
                SceneManager.LoadScene("EndScene");
            }
        }
    }
}
